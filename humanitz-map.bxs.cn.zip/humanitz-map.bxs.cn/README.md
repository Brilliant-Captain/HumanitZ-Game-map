# humanitzmap
Interactive HumanitZ map

https://humanitz-map.bxs.cn

# Change Logs
<details>
  <summary>V0.1.18</summary>
  - Change map to WebP to reduce the size
</details>

<details>
  <summary>V0.1.17</summary>
  - New icons (To make it a bit clearer.) 
  - New map image
</details>


# -
If you use the code some credits will be nice :)
